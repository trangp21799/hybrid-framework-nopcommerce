package org.testng.xml.dom;

public interface ITagFactory {

  Class<?> getClassForTag(String tag);
}
