package org.testng.internal.listeners;

import org.testng.annotations.Listeners;

@Listeners(EmptyExecutionListener.class)
public class TestClassWithListener {
}
