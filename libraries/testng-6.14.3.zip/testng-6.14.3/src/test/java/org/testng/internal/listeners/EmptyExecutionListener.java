package org.testng.internal.listeners;

import org.testng.IExecutionListener;

public class EmptyExecutionListener implements IExecutionListener {
    @Override
    public void onExecutionStart() {
    }

    @Override
    public void onExecutionFinish() {
    }
}
