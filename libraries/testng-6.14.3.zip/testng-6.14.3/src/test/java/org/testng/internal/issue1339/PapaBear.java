package org.testng.internal.issue1339;

public class PapaBear extends GrandpaBear {
    private void secretMethod(String foo) {

    }

    public void announcer(String foo) {

    }

    public void inheritable(String foo) {

    }

}
