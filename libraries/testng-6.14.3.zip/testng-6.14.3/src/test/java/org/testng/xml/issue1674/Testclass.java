package org.testng.xml.issue1674;

import org.testng.annotations.Test;

public class Testclass {
    @Test
    public void testMethod() {
    }
}
