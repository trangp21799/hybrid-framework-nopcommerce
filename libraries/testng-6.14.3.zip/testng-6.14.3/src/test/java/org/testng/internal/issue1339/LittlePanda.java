package org.testng.internal.issue1339;

public class LittlePanda extends PapaBear {
}
