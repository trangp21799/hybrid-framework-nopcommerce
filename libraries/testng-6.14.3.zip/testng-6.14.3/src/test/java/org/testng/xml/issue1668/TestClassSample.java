package org.testng.xml.issue1668;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestClassSample {
    @Test
    public void testMethod() {
        Assert.assertTrue(true);
    }
}
