package org.testng.internal.dynamicgraph;

import org.testng.annotations.Test;

public class IndependentTestClassSample {
    @Test
    public void a() {

    }

    @Test
    public void b() {

    }
}
