package org.testng.internal.issue1339;

public class GrandpaBear {
    private void secretMethod() {

    }

    public void announcer() {

    }

    public void inheritable() {

    }
}
