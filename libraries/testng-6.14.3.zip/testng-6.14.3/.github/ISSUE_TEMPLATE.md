### TestNG Version
> Note: only the latest version is supported

### Expected behavior


### Actual behavior


### Is the issue reproductible on runner?

- [ ] Shell
- [ ] Maven
- [ ] Gradle
- [ ] Ant
- [ ] Eclipse
- [ ] IntelliJ
- [ ] NetBeans


### Test case sample
> Please, share the test case (as small as possible) which shows the issue